package com.lgy.project_book_store.service;

import org.springframework.ui.Model;

public interface ProjectService {
	public int execute(Model model);
}